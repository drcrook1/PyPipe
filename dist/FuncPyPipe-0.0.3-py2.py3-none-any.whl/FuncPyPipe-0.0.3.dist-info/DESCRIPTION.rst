Makes composition of processing pipelines easier


